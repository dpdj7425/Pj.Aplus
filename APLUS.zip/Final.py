# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\ychoi\PycharmProjects\APLUS\Final.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Final(QtWidgets.QDialog):

    def __init__(self):
        super(Ui_Final, self).__init__()
        self.setupUi()

    def setupUi(self):
        Final.setObjectName("Final")
        Final.resize(500, 500)
        self.showFinal = QtWidgets.QLabel(Final)
        self.showFinal.setGeometry(QtCore.QRect(150, 40, 200, 200))
        self.showFinal.setText("")
        self.showFinal.setObjectName("showFinal")
        self.label = QtWidgets.QLabel(Final)
        self.label.setGeometry(QtCore.QRect(40, 430, 48, 48))
        self.label.setText("")
        self.label.setObjectName("label")
        self.ddss = QtWidgets.QLabel(Final)
        self.ddss.setGeometry(QtCore.QRect(90, 290, 351, 41))
        font = QtGui.QFont()
        font.setFamily("NanumGothic")
        font.setPointSize(16)
        self.ddss.setFont(font)
        self.ddss.setObjectName("ddss")
        self.label_2 = QtWidgets.QLabel(Final)
        self.label_2.setGeometry(QtCore.QRect(110, 470, 281, 16))
        self.label_2.setObjectName("label_2")
        self.pushButton = QtWidgets.QPushButton(Final)
        self.pushButton.setGeometry(QtCore.QRect(400, 370, 75, 23))
        self.pushButton.setObjectName("pushButton")

        self.retranslateUi(Final)
        self.pushButton.clicked.connect(Final.close)
        QtCore.QMetaObject.connectSlotsByName(Final)

        self.setWindowTitle(_translate("Final", "Dialog"))
        self.ddss.setText(_translate("Final", "최종 선정된 메뉴는 다음과 같습니다."))
        self.label_2.setText(_translate("Final", "<Copyright 2019. Project A+. All rights reserved.>"))
        self.pushButton.setText(_translate("Final", "Exit"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Final = QtWidgets.QDialog()
    ui = Ui_Final()
    ui.setupUi(Final)
    Final.show()
    sys.exit(app.exec_())

