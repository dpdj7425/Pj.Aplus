# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\ychoi\PycharmProjects\APLUS\forreport.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(500, 500)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.Explain = QtWidgets.QPushButton(self.centralwidget)
        self.Explain.setGeometry(QtCore.QRect(80, 10, 75, 23))
        self.Explain.setObjectName("Explain")
        self.Start = QtWidgets.QPushButton(self.centralwidget)
        self.Start.setGeometry(QtCore.QRect(80, 50, 75, 23))
        self.Start.setObjectName("Start")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(20, 15, 56, 12))
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(20, 56, 56, 12))
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setObjectName("label_2")
        self.Exit = QtWidgets.QPushButton(self.centralwidget)
        self.Exit.setGeometry(QtCore.QRect(390, 420, 75, 23))
        self.Exit.setObjectName("Exit")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(190, 10, 291, 61))
        self.label_3.setText("")
        self.label_3.setObjectName("label_3")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 500, 21))
        self.menubar.setObjectName("menubar")
        self.menuProject_A = QtWidgets.QMenu(self.menubar)
        self.menuProject_A.setObjectName("menuProject_A")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.actionZoSeongju = QtWidgets.QAction(MainWindow)
        self.actionZoSeongju.setObjectName("actionZoSeongju")
        self.menuProject_A.addAction(self.actionZoSeongju)
        self.menubar.addAction(self.menuProject_A.menuAction())

        self.retranslateUi(MainWindow)
        self.Exit.clicked.connect(MainWindow.close)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.Explain.setText(_translate("MainWindow", "Explain"))
        self.Start.setText(_translate("MainWindow", "Start"))
        self.label.setText(_translate("MainWindow", "도움말"))
        self.label_2.setText(_translate("MainWindow", "시작하기"))
        self.Exit.setText(_translate("MainWindow", "Exit"))
        self.menuProject_A.setTitle(_translate("MainWindow", "Project A+"))
        self.actionZoSeongju.setText(_translate("MainWindow", "ZoSeongju"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

