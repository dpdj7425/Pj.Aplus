import random


def Judge(K):
     for i in  range(K):
         if i >= 10:
             return str(K)
         else:
             pass


A={'A1': 0, 'A2': 0, 'A3': 0, 'A4': 0, 'A5': 0} # A: 스타일, 각각 양식, 중식, 일식, 한식, 패스트푸드
B={'B1': 0, 'B2': 0} #B:맛, 각각 매운맛, 안매운맛
C={'C1': 0, 'C2': 0, 'C3': 0, 'C4': 0, 'C5': 0, 'C6': 0} #C:재료, 각각 면, 밥, 육류, 해산물, 야채, 빵

Judge(A)